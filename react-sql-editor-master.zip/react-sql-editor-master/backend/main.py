from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import psycopg2

from fastapi.middleware.cors import CORSMiddleware

# import postgressql library  for connection


# Allow requests from all origins

origins = [
    "http://localhost",
    "http://localhost:8080",
    "http://localhost:3000",
    "http://localhost:8000",
]

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True, 
    allow_methods=["*"],
    allow_headers=["*"],
)

# Define the request body using Pydantic
class QueryRequest(BaseModel):
    query: str

# Define the connection string for postgres
connection = psycopg2.connect(user="postgres",
                                password="postgres",
                                host="7.tcp.eu.ngrok.io",
                                port="16195",
                                database="firewall")


@app.post("/execute_sql")
async def run_sql(query_request: QueryRequest):
    try:
        # Connect to the database
        cursor = connection.cursor()
        
        k = query_request.query
        print(k)
        try:
            cursor.execute(k)
            rows = cursor.fetchmany(50)
            columns = [col[0] for col in cursor.description]
        except:
            raise HTTPException(status_code=400, detail="Invalid SQL query")

        cursor.close()
        connection.close()
        
        return {
            "tableHeaders": columns,
            "tableRows": rows
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
